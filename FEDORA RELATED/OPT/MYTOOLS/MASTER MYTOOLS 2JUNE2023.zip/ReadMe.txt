# run it using

  sudo python3 download_wps.py

  # reset kde menu
  sudo kbuildsycoca5

